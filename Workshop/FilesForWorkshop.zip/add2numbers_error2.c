#include <stdio.h>
#include <stdlib.h>

int	main(int argc, char *argv[])
{
	int a;
	int b;

	a = argv[1];
	b = argv[2];    
	printf("a + b = %d\n", a + b);
	return (0);
}
